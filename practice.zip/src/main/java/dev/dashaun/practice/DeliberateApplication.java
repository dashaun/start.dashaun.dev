package dev.dashaun.practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeliberateApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeliberateApplication.class, args);
	}

}
